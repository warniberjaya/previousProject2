<?php 
	
	// This page is to find out the responsible agent's link that user clicks
	// Initialize the session
	session_start();
	
	$_SESSION['st'] = $_GET['st'];
	header("location: index.php");
?>


